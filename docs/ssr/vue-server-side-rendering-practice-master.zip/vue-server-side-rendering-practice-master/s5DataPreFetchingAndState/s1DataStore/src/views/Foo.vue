<template>
    <div>{{ fooCount }}</div>
</template>

<script>
import fooStoreModule from '../store/modules/foo'

export default {
  name: "Foo",
  computed: {
    fooCount () {
      return this.$store.state.foo.count
    }
  },

  serverPrefetch () {
    this.registerFoo()
    return this.fooInc()
  },

  mounted () {
    const alreadyIncremented =  !!this.$store.state.foo

    this.registerFoo()

    if (!alreadyIncremented) {
      this.fooInc()
    }
  },

  destroyed () {
    this.$store.unregisterModule('foo')
  },

  methods: {
    registerFoo () {
      this.$store.registerModule('foo', fooStoreModule, { preserveState: true })
    },

    fooInc () {
      return this.$store.dispatch('foo/inc')
    }
  }
};
</script>
<template>
    <div v-if="item">{{ item.title }}></div>
    <div v-else>...</div>
</template>

<script>
export default {
    computed: {
        item () {
            return this.$store.state.items[this.$route.params.id]
        }
    },


    serverPrefetch () {
        return this.fetchItem()
    },

    mounted() {
        if (!this.item) {
            this.fetchItem()
        }
    },

    methods: {
        fetchItem () {
            return this.$store.dispatch('fetchItem', this.$route.params.id)
        }
    }
}
</script>
<template>
    <h2>Hi, this is h2 in APP.vue</h2>
</template>
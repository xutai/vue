<template>
  <div>
    <h4>Home.vue</h4>
    <div>{{ fooCount }}</div>
  </div>
</template>

<script>
import fooStoreModule from "../store/modules/foo";
export default {
  name: "Home",
  computed: {
    fooCount() {
      return this.$store.state.foo.count;
    }
  },

  serverPrefetch() {
    this.registerFoo();
    return this.fooInc();
  },

  mounted() {
    const alreadyIncremented = !!this.$store.state.foo;

    // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Logical_Operators
    // Double NOT !!

    this.registerFoo();

    if (!alreadyIncremented) {
      this.fooInc();
    }
  },

  destroyed() {
    this.$store.unregisterModule("foo");
  },

  methods: {
      registerFoo () {
          this.$store.registerModule('foo', fooStoreModule, { preserveState: true })
      },

      fooInc () {
          return this.$store.dispatch('foo/inc')
      }
  }
};
</script>
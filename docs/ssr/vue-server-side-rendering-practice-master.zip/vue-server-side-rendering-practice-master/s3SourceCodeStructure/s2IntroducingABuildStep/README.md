

[vue loader](https://vue-loader.vuejs.org/guide/#vue-cli), 
`npm i -D vue-loader vue-template-compiler`



So far, we haven't discussed how to deliver the same Vue app to the client yet. To do that, we need to **use webpack** to bundle our Vue app. In fact, we probably want to use webpack to bundle the Vue app on the server as well, because:

Typical Vue apps are built with webpack and `vue-loader`, and many webpack-specific features such as importing files via `file-loader`, importing CSS via `css-loader` would not work directly in Node.js.

Although the latest version of Node.js fully supports ES2015 features, we still need to transpile client-side code to cater to older browsers. This again involves a build step.

So the basic idea is **we will be using webpack to bundle our app for both client and server** - the server bundle will be required by the server and used for SSR, while the client bundle is sent to the browser to hydrate the static markup.

We will discuss the details of the setup in later sections - for now, let's just assume we've got the build setup figured out and we can write our Vue app code with webpack enabled.

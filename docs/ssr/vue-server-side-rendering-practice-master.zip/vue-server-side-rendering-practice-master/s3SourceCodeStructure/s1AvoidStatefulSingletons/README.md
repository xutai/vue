


When writing client-only code, we are used to the fact that our code will be evaluated in a fresh context every time. However, a Node.js server is a long-running process. When our code is required into the process, it will be evaluated once and stays in memory. This means if you create a singleton object, it will be shared between every incoming request.

As seen in the basic example, we are creating a new root Vue instance for each request. This is similar to how each user will be using a fresh instance of the app in their own browser. If we use a shared instance across multiple requests, it will easily lead to cross-request state pollution.

So, instead of directly creating an app instance, we should **expose a factory function that can be repeatedly executed to create fresh app instances for each request**:


暴露一个工厂函数，哪个能够被重复执行，去创建新的app实例给每一个请求。


And our server code now becomes:

The same rule applies to **router, store and event bus instances** as well. Instead of exporting it directly from a module and importing it across your app, you need to **create a fresh instance in createApp and inject it from the root Vue instance**.

This constraint can be eliminated when using the bundle renderer with { runInNewContext: true }, however it comes with some significant performance cost because a new vm context needs to be created for each request.

什么意思？
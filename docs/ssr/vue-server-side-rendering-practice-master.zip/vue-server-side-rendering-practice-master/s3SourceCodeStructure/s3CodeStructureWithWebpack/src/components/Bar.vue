<template>
    <p>This is Bar.vue</p>
</template>
<template>
    <p>This is Foo.vue</p>
</template>
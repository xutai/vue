<template>
    <div id="app">
        <h1>hi, this is h1 in App.vue </h1>
        <Bar/>
        <Baz/>
        <Foo/>
    </div>
</template>


<script>
import Baz from './components/Baz'
import Bar from './components/Bar'
import Foo from './components/Foo'
export default {
    components: {
        Baz,
        Bar,
        Foo
    }
}
</script>
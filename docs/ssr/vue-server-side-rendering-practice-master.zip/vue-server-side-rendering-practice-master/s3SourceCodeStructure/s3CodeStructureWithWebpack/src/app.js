

import Vue from 'vue'
import App from './App.vue'

// export a factory function for creating fresh app, router and store
// instances
export function createApp () {
  const app = new Vue({
    // the root instance simply renders the App component.
    render: h => h(App)
  })
  return { app }
}



// return { app }, why not directly  `return app` ? 
// want to return an object?
// and is { app } equals to { app: app }



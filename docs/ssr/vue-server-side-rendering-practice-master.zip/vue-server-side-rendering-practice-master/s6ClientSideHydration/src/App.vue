<template>
  <div id="app">
    <h1>hi, this is h1 in App.vue</h1>

    <!--
    <Bar />
    <Baz />
    <Foo />
    -->

    <router-view/>


  </div>
</template>


<!--
<script>
/*
import Baz from "./components/Baz.vue";
import Bar from "./components/Bar.vue";
import Foo from "./components/Foo.vue";
*/

  /*
export default {
  name: "App"

  components: {
    Baz,
    Bar,
    Foo
  }
 
};
 */
</script>
-->
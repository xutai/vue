<template>
  <div v-if="fooCount">fooCount: {{ fooCount }}</div>
  <div v-else>fooCount does not exist</div>
</template>

<script>
import fooStoreModule from "../store/modules/foo";
import titleMixin from "../mixins/title-mixin";

export default {
  // name: "Foo",
  mixins: [titleMixin],
  title() {
    return "foo";
  },
  computed: {
    fooCount() {
      /* console.log(
        "Foo.vue - computed - fooCount(){} - this.$store.state:",
        this.$store.state
      );
      */
      return this.$store.state.foo.count;
    }
  },

  serverPrefetch() {
    // console.log("Foo.vue - serverPrefetch(){}");
    this.registerFooServer();
    // console.log("this.registerFoo() is executed");
    return this.fooInc();
  },

  mounted() {
    //  console.log("Foo.vue - mounted");
    const alreadyIncremented = !!this.$store.state.foo;

    this.registerFoo();

    if (!alreadyIncremented) {
      this.fooInc();
    }
  },

  destroyed() {
    // console.log("Foo.vue - destroyed() {}");
    this.$store.unregisterModule("foo");
  },

  methods: {
    registerFoo() {
      //   console.log('Foo.vue - method registerFoo(){}')
      //   console.log("fooStoreModule:",fooStoreModule)
      //   console.log("fooStoreModule.state:",fooStoreModule.state)
      //    console.log("fooStoreModule.state():",fooStoreModule.state())
      this.$store.registerModule("foo", fooStoreModule, {
        preserveState: false
      });
      /*   console.log(
        "Foo.vue - registerFoo(){} - this.$store.state",
        this.$store.state
      );
      console.log(
        "Foo.vue - registerFoo(){} - this.$store.state.foo",
        this.$store.state.foo
      );
      console.log(
        "Foo.vue - registerFoo(){} - this.$store.foo",
        this.$store.foo
      );
      console.log(
        "Foo.vue - registerFoo(){} - this.$store.modules",
        this.$store.modules
      );
      console.log(
        "Foo.vue - registerFoo(){} - this.$store.state.route",
        this.$store.state.route
      );
      */
    },
    registerFooServer() {
      this.$store.registerModule("foo", fooStoreModule, {
        preserveState: false
      });
    },

    fooInc() {
      /*
      console.log(
        "Foo.vue - fooInc(){} - this.$store.state:",
        this.$store.state
      );
      */
      return this.$store.dispatch("foo/inc");
    }
  }
};
</script>
<style scoped>
div {
  color: greenyellow;
  font-size: 5rem;
  background-color: ghostwhite;
}
</style>
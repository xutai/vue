

1. Create a Vue instance
2. Create a renderer
3. Render the Vue instance to HTML


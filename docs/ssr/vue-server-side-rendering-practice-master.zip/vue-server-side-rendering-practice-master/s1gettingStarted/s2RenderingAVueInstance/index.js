

// 1. create a Vue instance
const Vue = require('vue')
const app = new Vue({
    template: `<div>Hello World</div>`
})
// 2. Create a renderer
const renderer = require('vue-server-renderer').createRenderer()
// 3. Render the Vue instance to HTML
/* if provided callback
renderer.renderToString(app, (err, html) => {
    if (err) throw err
    console.log(html)
})
*/
// if does not provide callback
renderer.renderToString(app).then(html => {
    console.log(html)
}).catch(err => {
    console.error(err)
})


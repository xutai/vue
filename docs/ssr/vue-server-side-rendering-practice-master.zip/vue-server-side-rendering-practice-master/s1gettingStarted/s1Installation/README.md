

`npm install vue vue-server-renderer --save`
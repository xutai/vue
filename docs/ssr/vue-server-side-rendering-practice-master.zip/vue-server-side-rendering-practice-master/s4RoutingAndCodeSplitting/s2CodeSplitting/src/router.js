import Vue from 'Vue'
import Router from 'vue-router'
// import App from './App.vue'
// import Home from './views/Home.vue'
//import Foo from './components/Foo.vue'
//import Bar from './components/Bar.vue'

Vue.use(Router)

export function createRouter() {
    return new Router({
        mode: 'history',
        routes: [
            //   { path: '/', component: Home, name: 'home' },
            { path: '/', component: () => import('./views/Home.vue') },
            { path: '/foo', component: () => import('./components/Foo.vue') },
            { path: '/bar', component: () => import('./components/Bar.vue') }
        ]
    })
}
<template>
    <h4>Item.vue</h4>
</template>

<script>
export default {
    name: 'Item'
}
</script>
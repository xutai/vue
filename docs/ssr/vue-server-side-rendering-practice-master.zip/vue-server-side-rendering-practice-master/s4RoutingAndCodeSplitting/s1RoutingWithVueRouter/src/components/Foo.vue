<template>
    <p>This is Foo.vue</p>
</template>

<script>
export default {
  name: "Foo"
};
</script>
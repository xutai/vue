<template>
    <div class="home">
        <h3>Home</h3>
        <HelloWorld/>
    </div>
</template>


<script>
import HelloWorld from '../components/HelloWorld.vue'

export default {
    name: 'home',
    components: {
        HelloWorld
    }
}
</script>
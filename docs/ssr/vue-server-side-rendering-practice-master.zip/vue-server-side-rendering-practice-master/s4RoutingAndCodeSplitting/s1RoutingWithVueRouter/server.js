// server.js
 const createApp = require('./dist/built-server-bundle.js')

// console.log("server.js - createApp:", createApp)
// console.log("server.js - createApp.default:", createApp.default)

const server = require('express')()

const { createRenderer } = require('vue-server-renderer')



server.get('*', (req, res) => {
    const context = { url: req.url }

 //   console.log("server.js - url:", req.url)

    createApp.default(context).then(app => {

       // console.log("server.js - app:", app)


        const renderer = createRenderer({
            template: require('fs').readFileSync('./src/index.template.html', 'utf-8')
        })

  //      console.log("server.js - renderer:", renderer)

        const context = {
            title: 'this is title',
            meta: `
            <meta charset="utf-8">
            `
        }

        renderer.renderToString(app, context, (err, html) => {
            if (err) {
                if (err.code === 404) {
                    res.status(404).end('Page not found')
                } else {
                    res.status(500).end('Internal Server Error')
                }
            } else {
                res.end(html)
            }
        })
    }).catch(err => console.error(err))
})

server.listen(8080)
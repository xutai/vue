



## vue router does not work!!!!

## vue-ssr-outlet does not work!!!



问题来了： createApp() is not a function
查google[日文解决方案](https://qiita.com/webpack_master/items/229a4f15b99a19f94b76)
这里配置
```js
output: {
    libraryTarget: 'commonjs2'
}
```
看[configuration - output.libraryTarget](https://webpack.js.org/configuration/output/#outputlibrarytarget)
可能的值var, this, window, global, commonjs, commonjs2, amd,
amd-require, umd
测试发现commonjs, commonjs2可以用



为什么要用{}来包裹呢。就是说放到对象里？
我理解到比如这个{ app, router }， 当里面有2个以上时，就比较方便了
反正是返回一个对象吗，对象里面像发几个属性都可以

You may have noticed that our server code uses a `*` handler which accepts arbitrary URLs. This allows us to pass the visited URL into our Vue app, and reuse the same routing config for both client and server!

It is recommended to use the official `vue-router` for this purpose. Let's first create a file where we create the router. Note similar to `createApp`, we also need a fresh router instance for each request, so the file exports a `createRouter` function:


**The demo does not work now, just as the docs describes**
**I don't know how to make it working now**





##### app.js
1. create route instance
2. inject route into root Vue instance
3. return both the app and the router

##### entry-server.js





###### router.push(location, onComplete?, onAbort?)
[Vue Router - Guide - Essentials - Programmatic Navigation](https://router.vuejs.org/guide/essentials/navigation.html)


###### router.onReady(callback, [errorCallback])
[Vue Router - API Reference - Router Instance Methods - router.onReady](https://router.vuejs.org/api/#router-onready)

###### router.getMatchedComponents
[Vue Router - API Reference - Router Instance Methods - router.onReady](https://router.vuejs.org/api/#router-getmatchedcomponents)


###### Promise.reject(reason)
[Web technology for developers - JavaScript - JavaScript Reference - Standard built-in Objects - Promise - Promise reject()](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise/reject)


###### Promise.resolve(value)
[Web technology for developers - JavaScript - JavaScript Reference - Standard built-in Objects - Promise - Promise resolve()](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise/resolve)

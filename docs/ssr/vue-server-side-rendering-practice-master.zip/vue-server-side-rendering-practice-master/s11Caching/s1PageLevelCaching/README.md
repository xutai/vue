


`npx webpack --config webpack.server.config.js`

`npx webpack --config webpack.client.config.js`


<template>
    <p>Hello World</p>
</template>

<script>
export default {
    name: 'HelloWorld'
}
</script

<template>

    <p>This is Bar.vue</p>

</template>

<script>
export default {
  name: "Bar"
};
</script>
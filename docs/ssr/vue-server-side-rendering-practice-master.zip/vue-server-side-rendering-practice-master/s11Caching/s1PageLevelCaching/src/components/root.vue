<template>
    
</template>
<script>
// import Foo from './Foo.vue'
const Foo = () => import('./Foo.vue')
export default {
    
}
</script>

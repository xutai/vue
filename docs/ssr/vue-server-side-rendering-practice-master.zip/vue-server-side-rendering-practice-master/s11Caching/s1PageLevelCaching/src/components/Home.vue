<template>
    <h4>Home.vue</h4>
</template>

<script>
export default {
    name: 'Home'
}
</script>
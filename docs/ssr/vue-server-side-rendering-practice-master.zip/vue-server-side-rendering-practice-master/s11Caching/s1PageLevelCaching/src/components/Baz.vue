<template>
    <p>This is Baz.vue</p>
</template>
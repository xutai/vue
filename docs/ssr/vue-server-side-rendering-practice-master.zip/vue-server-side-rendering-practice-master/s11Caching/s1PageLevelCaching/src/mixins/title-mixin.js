

function getTitle (vm) {
  //  console.log("vm.$options.title:", vm.$options.title)
    // instance properties - vm.$options
    // https://vuejs.org/v2/api/#vm-options
    const { title } = vm.$options

    if(title) {
        return typeof title === 'function'
         ? title.call(vm)
         // what does this call() mean?
         // Function.prototype.call()
         // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function/call
         : title
    }
}

const serverTitleMixin = {
    created () {
       // console.log('serverTitleMixin - created(){}')
        const title = getTitle(this)
     //   console.log('title:', title)
        if (title) {
       //     console.log("this.$ssrContext:", this.$ssrContext)
            this.$ssrContext.title = title
        }
    }
}

const clientTitleMixin = {
    mounted () {
     //   console.log('clientTitleMixin - mounted(){}')
        const title = getTitle(this)
        if (title) {
            document.title = title
        }
    }
}

export default process.env.VUE_ENV === 'server'
    ? serverTitleMixin
    : clentTitleMixin
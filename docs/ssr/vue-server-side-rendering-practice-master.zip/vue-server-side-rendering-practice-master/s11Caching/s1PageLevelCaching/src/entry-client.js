import { createApp } from './app'

// client-specific bootstrapping logic...

// const { app } = createApp()
const { app, store } = createApp()

// this assumes App.vue template root element has `id="app"`
// app.$mount('#app')

/*
Note that it is still necessary to use router.onReady on both server and client before returning / mounting the app, 
because the router must resolve async route components ahead of time in order to properly invoke in-component hooks. 
We already did that in our server entry, and now we just need to update the client entry:
*/

/*
router.onReady(() => {
    app.$mount('#app')
})
*/

console.log("entry-client.js - window.__INITIAL_STATE__:", window.__INITIAL_STATE__)
if (window.__INITIAL_STATE__) {
    store.replaceState(window.__INITIAL_STATE__)
}

app.$mount('#app')
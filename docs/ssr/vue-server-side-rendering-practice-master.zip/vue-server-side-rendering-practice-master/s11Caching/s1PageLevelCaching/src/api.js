

export function fetchItem(id) {
    return { name: 'sth'}
}
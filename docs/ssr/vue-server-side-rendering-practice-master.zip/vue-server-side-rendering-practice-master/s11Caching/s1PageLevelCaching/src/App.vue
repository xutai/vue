<template>
  <div id="app">
    <h1>hi, this is h1 in App.vue</h1>

    <!--
    <Bar />
    <Baz />
    <Foo />
    -->

    <div id="nav">
      <router-link to="/">Home</router-link>|
      <router-link to="/foo">Foo</router-link>
    </div>

    
    <router-view />
  </div>
</template>



<script>
/*
import Baz from "./components/Baz.vue";
import Bar from "./components/Bar.vue";
import Foo from "./components/Foo.vue";
*/

 /*
export default {
  name: "App"
 
  components: {
    Baz,
    Bar,
    Foo
  }
  
};
*/

</script>

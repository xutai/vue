

// return { app }, why not directly  `return app` ? 
// want to return an object?
// and is { app } equals to { app: app }


// app.js
import Vue from 'vue'
import App from './App.vue'
import { createRouter } from './router'
import { createStore } from './store'
import { sync } from 'vuex-router-sync'

// export a factory function for creating fresh app, router and store
// instances
export function createApp() {
    // create router instance
    const router = createRouter()
    const store = createStore()

    sync(store, router)

    const app = new Vue({
        // inject router into Vue instance
        router,
        store,
        render: h => h(App)
    })


   // console.log("app.js - router:", router)
   // console.log("app.js - app:", app)

    // return both the app and the router
    return { app, router, store }
}


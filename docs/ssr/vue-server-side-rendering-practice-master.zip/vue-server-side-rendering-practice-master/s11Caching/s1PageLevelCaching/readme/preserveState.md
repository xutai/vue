

#### preserveState

[Store Code Splitting](https://ssr.vuejs.org/guide/data.html#store-code-splitting)

```html
 // Preserve the previous state if it was injected from the server

WARNING

Don't forget to use the preserveState: true option for registerModule so we keep the state injected by the server.
```

[Vuex - Core Concepts - Modules - Dynamic Module Registration - Preserving state](https://vuex.vuejs.org/guide/modules.html#preserving-state)

```
Preserving state

It may be likely that you want to preserve the previous state when registering a new module, such as preserving state from a Server Side Rendered app. You can achieve this with preserveState option: store.registerModule('a', module, { preserveState: true })

When you set preserveState: true, the module is registered, actions, mutations and getters are added to the store, but the state not. It's assumed that your store state already contains state for that module and you don't want to overwrite it.

#Module Reuse
```

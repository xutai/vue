

```js
Vue {
  _uid: 0,
  _isVue: true,
  '$options': {
    components: Object <[Object: null prototype] {
  KeepAlive: {
    name: 'keep-alive',
    abstract: true,
    props: { include: [Array], exclude: [Array], max: [Array] },
    created: [Function: created],
    destroyed: [Function: destroyed],
    mounted: [Function: mounted],
    render: [Function: render]
  },
  Transition: {
    name: 'transition',
    props: {
      name: [Function: String],
      appear: [Function: Boolean],
      css: [Function: Boolean],
      mode: [Function: String],
      type: [Function: String],
      enterClass: [Function: String],
      leaveClass: [Function: String],
      enterToClass: [Function: String],
      leaveToClass: [Function: String],
      enterActiveClass: [Function: String],
      leaveActiveClass: [Function: String],
      appearClass: [Function: String],
      appearActiveClass: [Function: String],
      appearToClass: [Function: String],
      duration: [Array]
    },
    abstract: true,
    render: [Function: render]
  },
  TransitionGroup: {
    props: {
      tag: [Function: String],
      moveClass: [Function: String],
      name: [Function: String],
      appear: [Function: Boolean],
      css: [Function: Boolean],
      type: [Function: String],
      enterClass: [Function: String],
      leaveClass: [Function: String],
      enterToClass: [Function: String],
      leaveToClass: [Function: String],
      enterActiveClass: [Function: String],
      leaveActiveClass: [Function: String],
      appearClass: [Function: String],
      appearActiveClass: [Function: String],
      appearToClass: [Function: String],
      duration: [Array]
    },
    beforeMount: [Function: beforeMount],
    render: [Function: render],
    updated: [Function: updated],
    methods: { hasMove: [Function: hasMove] }
  }
}> {},
    directives: Object <[Object: null prototype] {
  model: {
    inserted: [Function: inserted],
    componentUpdated: [Function: componentUpdated]
  },
  show: {
    bind: [Function: bind],
    update: [Function: update],
    unbind: [Function: unbind]
  }
}> {},
    filters: Object <[Object: null prototype] {}> {},
    _base: [Function: Vue] {
      util: [Object],
      set: [Function: set],
      delete: [Function: del],
      nextTick: [Function: nextTick],
      observable: [Function],
      options: [Object: null prototype],
      use: [Function],
      mixin: [Function],
      cid: 0,
      extend: [Function],
      component: [Function],
      directive: [Function],
      filter: [Function],
      version: '2.6.10'
    },
    router: VueRouter {
      app: null,
      apps: [],
      options: [Object],
      beforeHooks: [],
      resolveHooks: [],
      afterHooks: [],
      matcher: [Object],
      fallback: true,
      mode: 'abstract',
      history: [AbstractHistory]
    },
    render: [Function: render]
  },
  _renderProxy: [Circular],
  _self: [Circular],
  '$parent': undefined,
  '$root': [Circular],
  '$children': [],
  '$refs': {},
  _watcher: null,
  _inactive: null,
  _directInactive: false,
  _isMounted: false,
  _isDestroyed: false,
  _isBeingDestroyed: false,
  _events: [Object: null prototype] {},
  _hasHookEvent: false,
  _vnode: null,
  _staticTrees: null,
  '$vnode': undefined,
  '$slots': {},
  '$scopedSlots': {},
  _c: [Function],
  '$createElement': [Function],
  '$attrs': [Getter/Setter],
  '$listeners': [Getter/Setter],
  _watchers: [],
  _data: {}
}
```
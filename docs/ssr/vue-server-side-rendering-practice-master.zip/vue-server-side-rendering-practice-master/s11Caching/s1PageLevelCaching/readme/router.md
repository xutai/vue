

```js
VueRouter {
  app: null,
  apps: [],
  options: { mode: 'history', routes: [ [Object], [Object], [Object] ] },
  beforeHooks: [],
  resolveHooks: [],
  afterHooks: [],
  matcher: { match: [Function: match], addRoutes: [Function: addRoutes] },
  fallback: true,
  mode: 'abstract',
  history: AbstractHistory {
    router: [Circular],
    base: '',
    current: {
      name: undefined,
      meta: {},
      path: '/foo',
      hash: '',
      query: {},
      params: {},
      fullPath: '/foo',
      matched: [Array]
    },
    pending: null,
    ready: true,
    readyCbs: [],
    readyErrorCbs: [],
    errorCbs: [],
    stack: [ [Object] ],
    index: 0
  }
}
```
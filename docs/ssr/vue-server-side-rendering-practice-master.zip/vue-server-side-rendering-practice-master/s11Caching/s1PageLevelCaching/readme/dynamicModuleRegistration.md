

[Dynamic Module Registration](https://vuex.vuejs.org/guide/modules.html)
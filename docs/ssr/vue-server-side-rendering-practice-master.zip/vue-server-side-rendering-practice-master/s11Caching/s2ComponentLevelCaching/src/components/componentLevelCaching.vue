<template>
    <div>
        <div> {{ time }}  </div>
        <div> {{ getDate() }} </div>
    </div>
</template>

<script>
export default {
    data: () => ({
        time: new Date()
    }),
    methods: {
        getDate () {
            return new Date()
        }
    },
    name: 'cache',
    props: ['cache'],
    serverCacheKey: props => props.time,
    render (h) {
        return h('div', this.time)
    }
}
</script>
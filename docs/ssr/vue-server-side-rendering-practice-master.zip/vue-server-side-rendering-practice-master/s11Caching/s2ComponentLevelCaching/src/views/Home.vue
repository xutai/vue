<template>
    <div class="home">
        <h3>Home</h3>
        <HelloWorld/>
        <ComponentLevelCaching/>
    </div>
</template>


<script>
// import HelloWorld from '../components/HelloWorld.vue'
const HelloWorld = () => import('../components/HelloWorld.vue')
const ComponentLevelCaching = () => import('../components/componentLevelCaching.vue')

export default {
    name: 'home',
    components: {
        HelloWorld,
        ComponentLevelCaching

    }
}
</script>
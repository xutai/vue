
```js
PassThrough {
  _readableState: ReadableState {
    objectMode: false,
    highWaterMark: 16384,
    buffer: BufferList { head: null, tail: null, length: 0 },
    length: 0,
    pipes: null,
    pipesCount: 0,
    flowing: null,
    ended: false,
    endEmitted: false,
    reading: false,
    sync: false,
    needReadable: false,
    emittedReadable: false,
    readableListening: false,
    resumeScheduled: false,
    paused: true,
    emitClose: true,
    autoDestroy: false,
    destroyed: false,
    defaultEncoding: 'utf8',
    awaitDrain: 0,
    readingMore: false,
    decoder: null,
    encoding: null
  },
  readable: true,
  _events: [Object: null prototype] { prefinish: [Function: prefinish] },
  _eventsCount: 1,
  _maxListeners: undefined,
  _writableState: WritableState {
    objectMode: false,
    highWaterMark: 16384,
    finalCalled: false,
    needDrain: false,
    ending: false,
    ended: false,
    finished: false,
    destroyed: false,
    decodeStrings: true,
    defaultEncoding: 'utf8',
    length: 0,
    writing: false,
    corked: 0,
    sync: true,
    bufferProcessing: false,
    onwrite: [Function: bound onwrite],
    writecb: null,
    writelen: 0,
    bufferedRequest: null,
    lastBufferedRequest: null,
    pendingcb: 0,
    prefinished: false,
    errorEmitted: false,
    emitClose: true,
    autoDestroy: false,
    bufferedRequestCount: 0,
    corkedRequestsFree: {
      next: null,
      entry: null,
      finish: [Function: bound onCorkedFinish]
    }
  },
  writable: true,
  allowHalfOpen: true,
  _transformState: {
    afterTransform: [Function: bound afterTransform],
    needTransform: false,
    transforming: false,
    writecb: null,
    writechunk: null,
    writeencoding: null
  }
}
```

data:
```js
data: <Buffer 3c 64 69 76 20 69 64 3d 22 61 70 70 22 20 64 61 74 61 2d 73 65 72 76 65 72 2d 72 65 6e 64 65 72 65 64 3d 22 74 72 75 65 22 3e 3c 68 31 3e 68 69 2c 20 ... 360 more bytes>
```

html:
```js
html: <!DOCTYPE html>
<html lang="en">

<head>
    <title>new title</title>
    <meta width="device-width">
    <meta charset="utf-8" >


<link rel="preload" href="main.js" as="script"><link rel="preload" href="4.js" as="script"><link rel="preload" href="2.js" as="script"><link rel="preload" href="3.js" as="script"><link rel="prefetch" href="0.js"><link rel="prefetch" href="1.js"></head>


<body>
```

// server.js
//const createApp = require('./dist/main.js')

//console.log(createApp)

const server = require('express')()

const { createRenderer, createBundleRenderer } = require('vue-server-renderer')

// const renderer = createRenderer()


const serverBundle = require('./dist/vue-ssr-server-bundle.json')
const template = require('fs').readFileSync('./src/index.template.html', 'utf-8')
const clientManifest = require('./dist/vue-ssr-client-manifest.json')


//lru-cache
// https://www.npmjs.com/package/lru-cache
const LRU = require('lru-cache')


const microCache = new LRU({
    max: 10000,
    maxAge: 5000
})

const isCacheable = req => {
    //console.log("req.url:", req.url)
    if (req.url === '/foo') {
        return true
    } else {
        return false
    }
}



const renderer = createBundleRenderer(serverBundle, {
    runInNewContext: false,
    template,
    clientManifest,
    cache: nu=microCache
})




server.get('*', (req, res) => {


    const cacheable = isCacheable(req)
   // console.log("cacheable:", cacheable)
    if (cacheable) {
        const hit = microCache.get(req.url)
     //   console.log("hit:", hit)
        if (hit) {
            return res.end(hit)
        }
    }


    const context = {
        url: req.url,

        title: 'new title',
        meta: `<meta charset="utf-8" >`

    }

    /*
    createApp(context).then(app => {
        renderer.renderToString(app, (err, html) => {
            if (err) {
                if (err.code === 404) {
                    res.status(404).end('Page not found')
                } else {
                    res.status(500).end('Internal Server Error')
                }
            } else {
                res.end(html)
            }
        })
    })
    */

    /*
    renderer.renderToString(context, (err, html) => {
        res.end(html)

        if(cacheable) {
            microCache.set(req.url, html)
        }
    })
    */

    const stream = renderer.renderToStream(context)

    console.log(stream)
    let html = ''
    stream.on('data', data => {
        //console.log('data:',data)
        html += data.toString()
        //console.log('html:',html)
    })

    stream.on('end', () => {
        console.log(html)
        res.end(html)
    })

    stream.on('error', err => {

    })
    


})

server.listen(8080)
// server.js
const createApp = require('./dist/bundle.js')

console.log(createApp)

const server = require('express')()

const { createRenderer, createBundleRenderer } = require('vue-server-renderer')

// const renderer = createRenderer()

const renderer = createBundleRenderer(serverBundle, {
    runInNewContext: false,
    template,
    clientManifest
})

server.get('*', (req, res) => {
    const context = { url: req.url }

    /*
    createApp(context).then(app => {
        renderer.renderToString(app, (err, html) => {
            if (err) {
                if (err.code === 404) {
                    res.status(404).end('Page not found')
                } else {
                    res.status(500).end('Internal Server Error')
                }
            } else {
                res.end(html)
            }
        })
    })
    */

    renderer.renderToString(context, (err, html) => {
        res.end(html)
    })


})

server.listen(8080)
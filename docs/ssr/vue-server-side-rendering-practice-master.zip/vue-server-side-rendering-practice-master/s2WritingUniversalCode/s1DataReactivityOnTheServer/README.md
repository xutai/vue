

check docs


In a client-only app, every user will be using a fresh instance of the app in their browser. For server-side rendering we want the same: **each request should have a fresh, isolated app instance so that there is no cross-request state pollution**.

每一个请求都应该有一个新的，独立的app实例，这样没有跨请求状态污染。

Because the actual rendering process needs to be deterministic, we will also be **"pre-fetching" data on the server - this means our application state will be already resolved when we start rendering. This means data reactivity is unnecessary on the server, so it is disabled by default**. Disabling data reactivity also avoids the performance cost of converting data into reactive objects.

Vue的响应性reactivity在这里用不上，应用的状态会在我们开始渲染之前就已经解决了。

deterministic: 确定性的
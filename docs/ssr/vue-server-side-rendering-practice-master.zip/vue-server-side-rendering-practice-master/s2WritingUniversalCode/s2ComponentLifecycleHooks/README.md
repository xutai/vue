

check docs


Since there are no dynamic updates, of all the lifecycle hooks, only beforeCreate and created will be called during SSR. This means any code inside other lifecycle hooks such as beforeMount or mounted will only be executed on the client.


因为没有动态的更新，vue的生命周期勾子中，只有**created和beforeCreate**会在SSR中被调用。这就意味着任何在其他生命勾子中的代码，例如beforeMount或者mounted只会在客户端被执行。
什么意思？

Another thing to note is that you should avoid code that produces global side effects in beforeCreate and created, for example setting up timers with setInterval. In client-side only code we may setup a timer and then tear it down in beforeDestroy or destroyed. However, because the destroy hooks will not be called during SSR, the timers will stay around forever. To avoid this, move your side-effect code into beforeMount or mounted instead.



避免在beforeCreate和created里产生全局效果的代码，比如使用setInterval设置计时器。
在客户端会在beforeDestroy或destroyed中摧毁计时器，但是因为这两个勾子不会调用，所以一个计时器会一直持续下去。
为了避免这个，将副作用代码移到beforeMount或者mounted中。


看了这么多，感觉还是要测试一下才好。不然搞不明白哪个对哪个呢。
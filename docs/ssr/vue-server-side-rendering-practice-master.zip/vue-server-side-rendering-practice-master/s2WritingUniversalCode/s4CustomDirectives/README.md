

check docs



Most custom directives directly manipulate the DOM, and therefore will cause error during SSR. There are two ways to work around this:

大多数自定义指令直接操作DOM，并且因此会在SSR中造成错误。

Prefer using components as the abstraction mechanism and work at the Virtual-DOM level (e.g. using render functions) instead.


更偏向于使用组件作为抽象机制，并且致力于虚拟DOM的水平。


If you have a custom directive that cannot be easily replaced by components, you can provide a "server-side version" of it using the directives option when creating the server renderer.

如果你有一个自定义指定不能被轻易地被组件替代，你能提供一个它的服务端的版本，使用这个`directives`选项，当创建这个服务器渲染器时。
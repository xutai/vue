
check docs



Universal code cannot assume access to platform-specific APIs, so if your code directly uses browser-only globals like window or document, they will throw errors when executed in Node.js, and vice-versa.

For tasks shared between server and client but use different platform APIs, it's recommended to wrap the platform-specific implementations inside a universal API, or use libraries that do this for you. For example, axios is an HTTP client that exposes the same API for both server and client.

For browser-only APIs, the common approach is to lazily access them inside client-only lifecycle hooks.

Note that if a 3rd party library is not written with universal usage in mind, it could be tricky to integrate it into an server-rendered app. You might be able to get it working by mocking some of the globals, but it would be hacky and may interfere with the environment detection code of other libraries.


想办法处理平台指定的APIs。比如仅用于浏览器的window或者document。
axios是一个HTTP客户端，会将相同的API暴露给服务器和客户端。
对于仅限浏览器的APIs，这个一般的方法是，在仅限客户端生命周期勾子中，慢访问它们。

是有一些第三方包要留意。





This guide is focused on server-rendered Single-Page Applications **using Node.js as the server**. Mixing Vue SSR with other backend setups is a topic of its own and briefly discussed in a dedicated section.

这个教程专注于使用Node.js作为服务器，不过有其他教程可以看运行在其他的服务器

This guide will be very in-depth and assumes you are already familiar with Vue.js itself, and have decent working knowledge of Node.js and webpack. If you prefer a higher-level solution that provides a smooth out-of-the-box experience, you should probably **give Nuxt.js a try**. It's built upon the same Vue stack but abstracts away a lot of the boilerplate, and provides some extra features such as static site generation. However, it may not suit your use case if you need more direct control of your app's structure. Regardless, it would still be beneficial to read through this guide to better understand how things work together.

试试Nuxt.js如果你想要更改方便的话，不过如果你想要自己掌握你项目的结构，那么看看这个教程

As you read along, it would be helpful to refer to **the official HackerNews Demo**, which makes use of most of the techniques covered in this guide.

这有一个现成的案例，可以看着这个案列学这个教程

Finally, note that the solutions in this guide are not definitive - we've found them to be working well for us, but that doesn't mean they cannot be improved. They might get revised in the future - and feel free to contribute by submitting pull requests!

这个教程随时可能会改。
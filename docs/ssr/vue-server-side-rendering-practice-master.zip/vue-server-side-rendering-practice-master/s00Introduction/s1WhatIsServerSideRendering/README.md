
check the docs




#### client-side rendering
Vue.js is a framework for building client-side applications. By default, Vue components produce and manipulate DOM in the browser as output.

Vue默认是客户端渲染，Vue组件产生并在浏览器中操作DOM作为输出。

#### server-side rendering
However, it is also possible to render the same components into HTML strings on the server, send them directly to the browser, and finally "hydrate" the static markup into a fully interactive app on the client.

服务器将组件渲染成HTML字符串，然后发送给服务器，再hydrate静态标记成为一个客户端上的完全交互的app。